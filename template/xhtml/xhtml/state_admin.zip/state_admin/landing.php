<?php
// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Start session to maintain user state across pages
session_start();

// Include database configuration file
require_once '../config/config.php';

// Include email templates and functions
require_once 'email-templates.php';

// Check if user is logged in (commented out for development)
// if(!isset($_SESSION['admin_id'])) {
//     header("Location: login.php");
//     exit;
// }

// Handle bulk actions (approve/reject multiple practitioners)
if(isset($_POST['bulk_action']) && isset($_POST['selected_practitioners'])) {
    $bulk_action = $_POST['bulk_action'];
    $selected_practitioners = json_decode($_POST['selected_practitioners']);
    
    if($bulk_action == 'approve' || $bulk_action == 'reject') {
        $status = ($bulk_action == 'approve') ? 'Approved' : 'Inactive';
        $ids = implode(',', array_map('intval', $selected_practitioners));
        
        $sql = "UPDATE practitioner SET registration_status = ? WHERE practitioner_id IN ($ids)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $status);
        
        if($stmt->execute()) {
            $message = "Successfully " . ($bulk_action == 'approve' ? 'approved' : 'rejected') . " " . count($selected_practitioners) . " practitioners.";
            $alert_type = "success";
            
            // Send email notifications for approved practitioners
            if($bulk_action == 'approve') {
                // Get practitioner data for emails
                $practitioners_sql = "SELECT practitioner_id, practitioner_name, practitioner_email_id FROM practitioner WHERE practitioner_id IN ($ids)";
                $practitioners_result = $conn->query($practitioners_sql);
                
                $email_sent_count = 0;
                
                if($practitioners_result && $practitioners_result->num_rows > 0) {
                    while($practitioner_data = $practitioners_result->fetch_assoc()) {
                        // Send approval email using the function from email-templates.php
                        if(sendApprovalEmail($practitioner_data['practitioner_email_id'], $practitioner_data['practitioner_name'], $practitioner_data['practitioner_id'])) {
                            $email_sent_count++;
                        }
                    }
                    
                    if($email_sent_count > 0) {
                        $message .= " Email notifications sent to $email_sent_count practitioners.";
                    }
                }
            }
        } else {
            $message = "Error updating status: " . $conn->error;
            $alert_type = "danger";
        }
    }
}

// Handle individual status changes (approve/reject single practitioner)
if(isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    
    if($action == 'approve' || $action == 'reject') {
        $status = ($action == 'approve') ? 'Approved' : 'Inactive';
        
        $sql = "UPDATE practitioner SET registration_status = ? WHERE practitioner_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $id);
        
        if($stmt->execute()) {
            $message = "Practitioner has been " . ($action == 'approve' ? 'approved' : 'Inactive') . ".";
            $alert_type = "success";
            
            // Send email notification when status is set to Approved
            if($action == 'approve') {
                // Get practitioner data
                $get_practitioner_sql = "SELECT practitioner_name, practitioner_email_id FROM practitioner WHERE practitioner_id = ?";
                $get_stmt = $conn->prepare($get_practitioner_sql);
                $get_stmt->bind_param("i", $id);
                $get_stmt->execute();
                $result = $get_stmt->get_result();
                
                if($result->num_rows > 0) {
                    $practitioner_data = $result->fetch_assoc();
                    
                    // Send approval email using the function from email-templates.php
                    if(sendApprovalEmail($practitioner_data['practitioner_email_id'], $practitioner_data['practitioner_name'], $id)) {
                        $message .= " An email notification has been sent to the practitioner.";
                    }
                }
            }
        } else {
            $message = "Error updating status: " . $conn->error;
            $alert_type = "danger";
        }
    }
}

// Get total counts for dashboard statistics
$total_sql = "SELECT 
    COUNT(*) as total, 
    SUM(CASE WHEN registration_status = 'Approved' THEN 1 ELSE 0 END) as approved,
    SUM(CASE WHEN registration_status = 'Active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN registration_status = 'Pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN registration_status = 'Inactive' THEN 1 ELSE 0 END) as Inactive
FROM practitioner";

$total_result = $conn->query($total_sql);
$counts = $total_result->fetch_assoc();

// Set up pagination parameters
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get filter parameters from URL
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$search_term = isset($_GET['search']) ? $_GET['search'] : '';

// Build WHERE clause for filtering
$where_clause = "WHERE 1=1";
if($status_filter) {
    $where_clause .= " AND registration_status = '" . $conn->real_escape_string($status_filter) . "'";
}

if($search_term) {
    $where_clause .= " AND (practitioner_name LIKE '%" . $conn->real_escape_string($search_term) . "%' OR 
                           practitioner_email_id LIKE '%" . $conn->real_escape_string($search_term) . "%' OR
                           practitioner_mobile_number LIKE '%" . $conn->real_escape_string($search_term) . "%')";
}

// Fetch practitioners with pagination and filters
$sql = "SELECT p.*, rt.registration_type 
        FROM practitioner p
        LEFT JOIN registration_type_master rt ON p.registration_type_id = rt.registration_type_id
        $where_clause
        ORDER BY p.practitioner_id DESC 
        LIMIT $offset, $limit";

$result = $conn->query($sql);

// Calculate total pages for pagination
$total_sql = "SELECT COUNT(*) as total FROM practitioner $where_clause";
$total_result = $conn->query($total_sql);
$total_row = $total_result->fetch_assoc();
$total_pages = ceil($total_row['total'] / $limit);

// Set page title
$pageTitle = "Admin Dashboard | Karnataka State Allied & Healthcare Council";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
	    <!-- Title -->
	<title>W3CRM - Bootstrap Admin Dashboard Template</title>
	
	<!-- Meta -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="DexignZone">
	<meta name="robots" content="index, follow">
	<meta name="format-detection" content="telephone=no">
	
	<meta name="keywords" content="admin, admin dashboard, bootstrap, template, analytics, dark mode, modern, responsive admin dashboard, sass, ui kit">
	<meta name="description" content="Elevate your administrative efficiency and enhance productivity with the W3CRM Bootstrap Admin Dashboard Template. Designed to streamline your tasks, this powerful tool provides a user-friendly interface, robust features, and customizable options, making it the ideal choice for managing your data and operations with ease.">
	
	<meta property="og:title" content="W3CRM - Bootstrap Admin Dashboard Template">
	<meta property="og:description" content="Elevate your administrative efficiency and enhance productivity with the W3CRM Bootstrap Admin Dashboard Template. Designed to streamline your tasks, this powerful tool provides a user-friendly interface, robust features, and customizable options, making it the ideal choice for managing your data and operations with ease.">
	<meta property="og:image" content="https://w3crm.dexignzone.com/xhtml/social-image.png">
	
	<!-- TWITTER META -->
	<meta name="twitter:title" content="W3CRM - Bootstrap Admin Dashboard Template">
	<meta name="twitter:description" content="Elevate your administrative efficiency and enhance productivity with the W3CRM Bootstrap Admin Dashboard Template. Designed to streamline your tasks, this powerful tool provides a user-friendly interface, robust features, and customizable options, making it the ideal choice for managing your data and operations with ease.">
	<meta name="twitter:image" content="https://w3crm.dexignzone.com/xhtml/social-image.png">
	<meta name="twitter:card" content="summary_large_image">
	
	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="../assets/images/favicon.png">
	
	<!-- MOBILE SPECIFIC -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- Canonical URL -->
	<link rel="canonical" href="https://w3crm.dexignzone.com/xhtml/task.html">
	
	<!-- Plugins Stylesheet -->
	<link href="../assets/css/jquery.localizationTool.css" rel="stylesheet">
	<link href="../assets/vendor/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet">
	
	
	<link href="../assets/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
	<link href="../assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet">	
	<link href="../assets/vendor/tagify/tagify.css" rel="stylesheet">
	
    <!-- Style CSS -->
	<link href="../assets/css/plugins.css" rel="stylesheet">
	<link href="../assets/css/style.css" rel="stylesheet">
	
</head>
<body>

    	<!-- Start - Preloader -->
	<div id="preloader">
		<div class="lds-ripple">
			<div></div>
			<div></div>
		</div>
	</div>
	<!-- End - Preloader -->

	<!-- Start - Main Wrapper -->
    <div id="main-wrapper">
        
			<!--**********************************
		Nav header start
	***********************************-->
	<div class="nav-header">
		<a href="index.html" class="brand-logo" aria-label="Brand Logo">
			<svg class="logo-abbr" width="39" height="23" viewBox="0 0 39 23" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path class="w3" d="M32.0362 22H19.0466L20.7071 18.7372C20.9559 18.2484 21.455 17.9378 22.0034 17.9305L31.1036 17.8093C33.0753 17.6497 33.6571 15.9246 33.7015 15.0821C33.7015 13.2196 32.1916 12.5765 31.4367 12.4878H23.7095L25.9744 8.49673H30.4375C31.8763 8.3903 32.236 7.03332 32.236 6.36814C32.3426 4.93133 30.9482 4.61648 30.2376 4.63865H28.6955C28.2646 4.63865 27.9788 4.19212 28.1592 3.8008L29.7047 0.44798C31.0903 0.394765 32.8577 0.780573 33.5683 0.980129C38.6309 3.42801 37.0988 7.98676 35.6999 9.96014C38.1513 11.9291 38.4976 14.3282 38.3644 15.2816C38.098 20.1774 34.0346 21.8005 32.0362 22Z" fill="var(--primary)"/>
				<path class="react-w" d="M9.89261 21.4094L0 2.80536H4.86354C5.41354 2.80536 5.91795 3.11106 6.17246 3.59864L12.4032 15.5355C12.6333 15.9762 12.6261 16.5031 12.3842 16.9374L9.89261 21.4094Z" fill="white"/>
				<path class="react-w" d="M17.5705 21.4094L7.67786 2.80536H12.5372C13.0894 2.80536 13.5954 3.11351 13.8489 3.60412L20.302 16.0939L17.5705 21.4094Z" fill="white"/>
				<path class="react-w" d="M17.6443 21.4094L28.2751 0H23.4513C22.8806 0 22.361 0.328884 22.1168 0.844686L14.8271 16.2416L17.6443 21.4094Z" fill="white"/>
				<path class="react-w" d="M9.89261 21.4094L0 2.80536H4.86354C5.41354 2.80536 5.91795 3.11106 6.17246 3.59864L12.4032 15.5355C12.6333 15.9762 12.6261 16.5031 12.3842 16.9374L9.89261 21.4094Z" stroke="white"/>
				<path class="react-w" d="M17.5705 21.4094L7.67786 2.80536H12.5372C13.0894 2.80536 13.5954 3.11351 13.8489 3.60412L20.302 16.0939L17.5705 21.4094Z" stroke="white"/>
				<path class="react-w" d="M17.6443 21.4094L28.2751 0H23.4513C22.8806 0 22.361 0.328884 22.1168 0.844686L14.8271 16.2416L17.6443 21.4094Z" stroke="white"/>
			</svg>
			<svg class="brand-title" width="47" height="16" viewBox="0 0 47 16" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M8.36 15.2C7.2933 15.2 6.3 15.0267 5.38 14.68C4.4733 14.32 3.68 13.82 3 13.18C2.3333 12.5267 1.8133 11.76 1.44 10.88C1.0667 9.99999 0.880005 9.03999 0.880005 7.99999C0.880005 6.95999 1.0667 5.99999 1.44 5.11999C1.8133 4.23999 2.34 3.47999 3.02 2.83999C3.7 2.18666 4.49331 1.68666 5.40001 1.33999C6.30671 0.979988 7.3 0.799988 8.38 0.799988C9.5267 0.799988 10.5733 0.999988 11.52 1.39999C12.4667 1.78666 13.2667 2.36666 13.92 3.13999L12.24 4.71999C11.7333 4.17332 11.1667 3.76666 10.54 3.49999C9.9133 3.21999 9.2333 3.07999 8.5 3.07999C7.7667 3.07999 7.0933 3.19999 6.48 3.43999C5.88 3.67999 5.35331 4.01999 4.90001 4.45999C4.46001 4.89999 4.1133 5.41999 3.86 6.01999C3.62 6.61999 3.5 7.27999 3.5 7.99999C3.5 8.71999 3.62 9.37999 3.86 9.97999C4.1133 10.58 4.46001 11.1 4.90001 11.54C5.35331 11.98 5.88 12.32 6.48 12.56C7.0933 12.8 7.7667 12.92 8.5 12.92C9.2333 12.92 9.9133 12.7867 10.54 12.52C11.1667 12.24 11.7333 11.82 12.24 11.26L13.92 12.86C13.2667 13.62 12.4667 14.2 11.52 14.6C10.5733 15 9.52 15.2 8.36 15.2ZM16.4113 15V0.999988H22.1713C23.4113 0.999988 24.4713 1.19999 25.3513 1.59999C26.2446 1.99999 26.9313 2.57332 27.4113 3.31999C27.8913 4.06666 28.1313 4.95332 28.1313 5.97999C28.1313 7.00669 27.8913 7.89329 27.4113 8.63999C26.9313 9.37329 26.2446 9.93999 25.3513 10.34C24.4713 10.7267 23.4113 10.92 22.1713 10.92H17.8513L19.0113 9.73999V15H16.4113ZM25.5713 15L22.0313 9.91999H24.8112L28.3713 15H25.5713ZM19.0113 10.02L17.8513 8.77999H22.0513C23.1979 8.77999 24.0579 8.53329 24.6312 8.03999C25.2179 7.54669 25.5113 6.85999 25.5113 5.97999C25.5113 5.08666 25.2179 4.39999 24.6312 3.91999C24.0579 3.43999 23.1979 3.19999 22.0513 3.19999H17.8513L19.0113 1.91999V10.02ZM31.0402 15V0.999988H33.1802L39.3002 11.22H38.1802L44.2002 0.999988H46.3402L46.3602 15H43.9002L43.8802 4.85999H44.4002L39.2802 13.4H38.1202L32.9202 4.85999H33.5202V15H31.0402Z" fill="black"/>
			</svg>
		</a>
		<div class="nav-control">
			<div class="hamburger">
				<span class="line"></span>
				<span class="line"></span>
				<span class="line"></span>
			</div>
		</div>
	</div>
	<!--**********************************
		Nav header end
	***********************************-->
		
			<!-- Start - Sidebar Chat Box  -->
	<div class="chatbox">
		<div class="chatbox-close"></div>
		<div class="clearfix">
			<ul class="nav nav-underline">
				<li class="nav-item">
					<a class="nav-link" data-bs-toggle="tab" href="#notes">Notes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" data-bs-toggle="tab" href="#alerts">Alerts</a>
				</li>
				<li class="nav-item">
					<a class="nav-link active" data-bs-toggle="tab" href="#chat">Chat</a>
				</li>
			</ul>
			<div class="tab-content">
				<div class="tab-pane fade active show" id="chat">
					<div class="card mb-sm-3 mb-md-0 contacts_card dz-chat-user-box">
						<div class="card-header chat-list-header text-center">
							<a href="javascript:void(0);">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect fill="var(--bs-heading-color)" x="4" y="11" width="16" height="2" rx="1"/>
										<rect fill="var(--bs-heading-color)" opacity="1.0" transform="translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000) " x="4" y="11" width="16" height="2" rx="1"/>
									</g>
								</svg>
							</a>
							<div class="clearfix">
								<h6 class="mb-1">Chat List</h6>
								<p class="mb-0">Show All</p>
							</div>
							<a href="javascript:void(0);">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect x="0" y="0" width="24" height="24"/>
										<circle fill="var(--bs-heading-color)" cx="5" cy="12" r="2"/>
										<circle fill="var(--bs-heading-color)" cx="12" cy="12" r="2"/>
										<circle fill="var(--bs-heading-color)" cx="19" cy="12" r="2"/>
									</g>
								</svg>
							</a>
						</div>
						<div class="card-body contacts_body p-0 dz-scroll  " id="DZ_W_Contacts_Body">
							<ul class="contacts">
								<li class="name-first-letter">A</li>
								<li class="active dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>Archie Parker</span>
											<p>Kalid is online</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Alfie Mason</span>
											<p>Taherah left 7 mins ago</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar3.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>AharlieKane</span>
											<p>Sami is online</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar4.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Athan Jacoby</span>
											<p>Nargis left 30 mins ago</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">B</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar5.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Bashid Samim</span>
											<p>Rashid left 50 mins ago</p>
										</div>
									</div>
								</li>
								<li class="dz- -user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar6.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>Breddie Ronan</span>
											<p>Kalid is online</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar7.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Ceorge Carson</span>
											<p>Taherah left 7 mins ago</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">D</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar8.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>Darry Parker</span>
											<p>Sami is online</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar9.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Denry Hunter</span>
											<p>Nargis left 30 mins ago</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">J</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar10.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Jack Ronan</span>
											<p>Rashid left 50 mins ago</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>Jacob Tucker</span>
											<p>Kalid is online</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>James Logan</span>
											<p>Taherah left 7 mins ago</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar3.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon"></span>
										</div>
										<div class="user_info">
											<span>Joshua Weston</span>
											<p>Sami is online</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">O</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar4.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Oliver Acker</span>
											<p>Nargis left 30 mins ago</p>
										</div>
									</div>
								</li>
								<li class="dz-chat-user">
									<div class="d-flex bd-highlight">
										<div class="img_cont">
											<img src="../assets/images/avatar/small/avatar5.webp" class="rounded-circle user_img" alt="">
											<span class="online_icon offline"></span>
										</div>
										<div class="user_info">
											<span>Oscar Weston</span>
											<p>Rashid left 50 mins ago</p>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="card chat dz-chat-history-box d-none">
						<div class="card-header chat-list-header text-center">
							<a href="javascript:void(0);" class="dz-chat-history-back">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<polygon points="0 0 24 0 24 24 0 24"/>
										<rect fill="var(--bs-heading-color)" opacity="0.3" transform="translate(15.000000, 12.000000) scale(-1, 1) rotate(-90.000000) translate(-15.000000, -12.000000)" x="14" y="7" width="2" height="10" rx="1"/>
										<path d="M3.7071045,15.7071045 C3.3165802,16.0976288 2.68341522,16.0976288 2.29289093,15.7071045 C1.90236664,15.3165802 1.90236664,14.6834152 2.29289093,14.2928909 L8.29289093,8.29289093 C8.67146987,7.914312 9.28105631,7.90106637 9.67572234,8.26284357 L15.6757223,13.7628436 C16.0828413,14.136036 16.1103443,14.7686034 15.7371519,15.1757223 C15.3639594,15.5828413 14.7313921,15.6103443 14.3242731,15.2371519 L9.03007346,10.3841355 L3.7071045,15.7071045 Z" fill="var(--bs-heading-color)" fill-rule="nonzero" transform="translate(9.000001, 11.999997) scale(-1, -1) rotate(90.000000) translate(-9.000001, -11.999997) "/>
									</g>
								</svg>
							</a>
							<div class="clearfix">
								<h6 class="mb-1">Chat with Verla Morgano</h6>
								<p class="mb-0 text-success">Online</p>
							</div>							
							<div class="dropdown">
								<a href="javascript:void(0);" role="button" data-bs-toggle="dropdown" aria-expanded="false" class="dz-chat-dropdown dz-chatbox-btn">
									<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
										<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
											<rect x="0" y="0" width="24" height="24"/>
											<circle fill="var(--bs-heading-color)" cx="5" cy="12" r="2"/>
											<circle fill="var(--bs-heading-color)" cx="12" cy="12" r="2"/>
											<circle fill="var(--bs-heading-color)" cx="19" cy="12" r="2"/>
										</g>
									</svg>
								</a>
								<ul class="dropdown-menu dropdown-menu-end">
									<li><a class="dropdown-item" href="javascript:void(0);"><i class="fa fa-user-circle text-primary me-1"></i> View profile</a></li>
									<li><a class="dropdown-item" href="javascript:void(0);"><i class="fa fa-users text-primary me-1"></i> Add to Friends</a></li>
									<li><a class="dropdown-item" href="javascript:void(0);"><i class="fa fa-plus text-primary me-1"></i> Add to group</a></li>
									<li><a class="dropdown-item" href="javascript:void(0);"><i class="fa fa-ban text-primary me-1"></i> Block</a></li>
								</ul>
							</div>
						</div>
						<div class="card-body msg_card_body dz-scroll" id="DZ_W_Contacts_Body3">
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									Hi, how are you samim?
									<span class="msg_time">8:40 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									Hi Khalid i am good tnx how about you?
									<span class="msg_time_send">8:55 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									I am good too, thank you for your chat template
									<span class="msg_time">9:00 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									You are welcome
									<span class="msg_time_send">9:05 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									I am looking for your next templates
									<span class="msg_time">9:07 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									Ok, thank you have a good day
									<span class="msg_time_send">9:10 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									Bye, see you
									<span class="msg_time">9:12 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									Hi, how are you samim?
									<span class="msg_time">8:40 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									Hi Khalid i am good tnx how about you?
									<span class="msg_time_send">8:55 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									I am good too, thank you for your chat template
									<span class="msg_time">9:00 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									You are welcome
									<span class="msg_time_send">9:05 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									I am looking for your next templates
									<span class="msg_time">9:07 AM, Today</span>
								</div>
							</div>
							<div class="d-flex justify-content-end mb-4">
								<div class="msg_cotainer_send">
									Ok, thank you have a good day
									<span class="msg_time_send">9:10 AM, Today</span>
								</div>
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar2.webp" class="rounded-circle user_img_msg" alt="">
								</div>
							</div>
							<div class="d-flex justify-content-start mb-4">
								<div class="img_cont_msg">
									<img src="../assets/images/avatar/small/avatar1.webp" class="rounded-circle user_img_msg" alt="">
								</div>
								<div class="msg_cotainer">
									Bye, see you
									<span class="msg_time">9:12 AM, Today</span>
								</div>
							</div>
						</div>
						<div class="card-footer type_msg">
							<div class="input-group">
								<textarea class="form-control" placeholder="Type your message..."></textarea>
								<div class="input-group-append">
									<button type="button" class="btn btn-primary"><i class="fa fa-location-arrow"></i></button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="alerts">
					<div class="card mb-sm-3 mb-md-0 contacts_card">
						<div class="card-header chat-list-header text-center">
							<a href="javascript:void(0);" class="dz-chatbox-btn">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect x="0" y="0" width="24" height="24"/>
										<circle fill="var(--bs-heading-color)" cx="5" cy="12" r="2"/>
										<circle fill="var(--bs-heading-color)" cx="12" cy="12" r="2"/>
										<circle fill="var(--bs-heading-color)" cx="19" cy="12" r="2"/>
									</g>
								</svg>
							</a>
							<div class="clearfix">
								<h6 class="mb-1">Notications</h6>
								<p class="mb-0">Show All</p>
							</div>
							<a href="javascript:void(0);" class="dz-chatbox-btn">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect x="0" y="0" width="24" height="24"/>
										<path d="M14.2928932,16.7071068 C13.9023689,16.3165825 13.9023689,15.6834175 14.2928932,15.2928932 C14.6834175,14.9023689 15.3165825,14.9023689 15.7071068,15.2928932 L19.7071068,19.2928932 C20.0976311,19.6834175 20.0976311,20.3165825 19.7071068,20.7071068 C19.3165825,21.0976311 18.6834175,21.0976311 18.2928932,20.7071068 L14.2928932,16.7071068 Z" fill="var(--bs-heading-color)" fill-rule="nonzero" opacity="1"/>
										<path d="M11,16 C13.7614237,16 16,13.7614237 16,11 C16,8.23857625 13.7614237,6 11,6 C8.23857625,6 6,8.23857625 6,11 C6,13.7614237 8.23857625,16 11,16 Z M11,18 C7.13400675,18 4,14.8659932 4,11 C4,7.13400675 7.13400675,4 11,4 C14.8659932,4 18,7.13400675 18,11 C18,14.8659932 14.8659932,18 11,18 Z" fill="var(--bs-heading-color)" fill-rule="nonzero"/>
									</g>
								</svg>
							</a>
						</div>
						<div class="card-body contacts_body p-0 dz-scroll" id="DZ_W_Contacts_Body1">
							<ul class="contacts">
								<li class="name-first-letter">SEVER STATUS</li>
								<li class="active">
									<div class="d-flex bd-highlight">
										<div class="img_cont primary">KK</div>
										<div class="user_info">
											<span>David Nester Birthday</span>
											<p class="text-primary">Today</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">SOCIAL</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="img_cont success">RU</div>
										<div class="user_info">
											<span>Perfection Simplified</span>
											<p>Jame Smith commented on your status</p>
										</div>
									</div>
								</li>
								<li class="name-first-letter">SEVER STATUS</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="img_cont primary">AU</div>
										<div class="user_info">
											<span>AharlieKane</span>
											<p>Sami is online</p>
										</div>
									</div>
								</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="img_cont info">MO</div>
										<div class="user_info">
											<span>Athan Jacoby</span>
											<p>Nargis left 30 mins ago</p>
										</div>
									</div>
								</li>
							</ul>
						</div>
						<div class="card-footer"></div>
					</div>
				</div>
				<div class="tab-pane fade" id="notes">
					<div class="card mb-sm-3 mb-md-0 note_card">
						<div class="card-header chat-list-header text-center">
							<a href="javascript:void(0);" class="dz-chatbox-btn">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect fill="var(--bs-heading-color)" x="4" y="11" width="16" height="2" rx="1"/>
										<rect fill="var(--bs-heading-color)" opacity="1.0" transform="translate(12.000000, 12.000000) rotate(-270.000000) translate(-12.000000, -12.000000) " x="4" y="11" width="16" height="2" rx="1"/>
									</g>
								</svg>
							</a>
							<div class="clarfix">
								<h6 class="mb-1">Notes</h6>
								<p class="mb-0">Add New Nots</p>
							</div>
							<a href="javascript:void(0);" class="dz-chatbox-btn">
								<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect x="0" y="0" width="24" height="24"/>
										<path d="M14.2928932,16.7071068 C13.9023689,16.3165825 13.9023689,15.6834175 14.2928932,15.2928932 C14.6834175,14.9023689 15.3165825,14.9023689 15.7071068,15.2928932 L19.7071068,19.2928932 C20.0976311,19.6834175 20.0976311,20.3165825 19.7071068,20.7071068 C19.3165825,21.0976311 18.6834175,21.0976311 18.2928932,20.7071068 L14.2928932,16.7071068 Z" fill="var(--bs-heading-color)" fill-rule="nonzero" opacity="1"/>
										<path d="M11,16 C13.7614237,16 16,13.7614237 16,11 C16,8.23857625 13.7614237,6 11,6 C8.23857625,6 6,8.23857625 6,11 C6,13.7614237 8.23857625,16 11,16 Z M11,18 C7.13400675,18 4,14.8659932 4,11 C4,7.13400675 7.13400675,4 11,4 C14.8659932,4 18,7.13400675 18,11 C18,14.8659932 14.8659932,18 11,18 Z" fill="var(--bs-heading-color)" fill-rule="nonzero"/>
									</g>
								</svg>
							</a>
						</div>
						<div class="card-body contacts_body p-0 dz-scroll" id="DZ_W_Contacts_Body2">
							<ul class="contacts">
								<li class="active">
									<div class="d-flex bd-highlight">
										<div class="user_info">
											<span>New order placed..</span>
											<p>10 Aug 2020</p>
										</div>
										<div class="ms-auto">
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-primary light ms-1"><i class="fas fa-pencil-alt"></i></a>
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-danger light"><i class="fa fa-trash"></i></a>
										</div>
									</div>
								</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="user_info">
											<span>Youtube, a video-sharing website..</span>
											<p>10 Aug 2020</p>
										</div>
										<div class="ms-auto">
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-primary light ms-1"><i class="fas fa-pencil-alt"></i></a>
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-danger light"><i class="fa fa-trash"></i></a>
										</div>
									</div>
								</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="user_info">
											<span>john just buy your product..</span>
											<p>10 Aug 2020</p>
										</div>
										<div class="ms-auto">
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-primary light ms-1"><i class="fas fa-pencil-alt"></i></a>
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-danger light"><i class="fa fa-trash"></i></a>
										</div>
									</div>
								</li>
								<li>
									<div class="d-flex bd-highlight">
										<div class="user_info">
											<span>Athan Jacoby</span>
											<p>10 Aug 2020</p>
										</div>
										<div class="ms-auto">
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-primary light ms-1"><i class="fas fa-pencil-alt"></i></a>
											<a href="javascript:void(0);" class="btn btn-square btn-xs btn-danger light"><i class="fa fa-trash"></i></a>
										</div>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End - Sidebar Chat Box  -->
		
			<!-- Start - Header -->
	<div class="header">
		<div class="header-content">
			<nav class="navbar navbar-expand">
				<div class="collapse navbar-collapse justify-content-between">
					<div class="header-left">
						<form>
							<div class="header-search input-group">
								<span class="input-group-text">
									<button class="bg-transparent border-0" aria-label="Header Search">
										<svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
											<circle cx="8.78605" cy="8.78605" r="8.23951" stroke="var(--bs-body-color)" stroke-linecap="round" stroke-linejoin="round"/>
											<path d="M14.5168 14.9447L17.7471 18.1667" stroke="var(--bs-body-color)" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
									</button>
								</span>
								<input type="text" class="form-control" placeholder="Search">
							</div>
						</form>	
					</div>
					<ul class="navbar-nav header-right">
						<li class="nav-item">
							<div id="selectLanguageDropdown" class="localizationTool"></div>
						</li>
						<li class="nav-item dropdown notification_dropdown">
							<div class="dropdown">
								<button class="nav-link" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notification Dropdown">
									<svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z" stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
										<path d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21" stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
									</svg>
								</button>
								<div class="dropdown-menu dropdown-menu-end py-0">
									<div class="dz-scroll p-2" style="height: 380px;">
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<img src="../../assets/images/avatar/small/avatar1.webp" alt="" class="rounded-circle avatar avatar-sm">
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Dr sultads Send you Photo</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<div class="avatar avatar-sm avatar-success rounded-circle">KG</div>
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Resport created successfully</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<div class="avatar avatar-sm avatar-primary rounded-circle"><i class="fa fa-home"></i></div>
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Reminder : Treatment Time!</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<img src="../assets/images/avatar/small/avatar2.webp" alt="" class="rounded-circle avatar avatar-sm">
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Resport created successfully</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<img src="../assets/images/avatar/small/avatar3.webp" alt="" class="rounded-circle avatar avatar-sm">
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Dr sultads Send you Photo</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<div class="avatar avatar-sm avatar-success rounded-circle">KG</div>
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Resport created successfully</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<div class="avatar avatar-sm avatar-primary rounded-circle"><i class="fa fa-home"></i></div>
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Reminder : Treatment Time!</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
										<div class="d-flex align-items-center p-2 bg-action-light rounded">
											<div class="d-inline-block">
												<img src="../assets/images/avatar/small/avatar4.webp" alt="" class="rounded-circle avatar avatar-sm">
											</div>
											<div class="clearfix ms-2">
												<h6 class="fs-13 mb-0 fw-semibold">Resport created successfully</h6>
												<small>29 July 2020 - 02:26 PM</small>
											</div>
										</div>
									</div>
									<a class="d-block text-center p-3 border-top" href="javascript:void(0);">See all notifications <i class="fa fa-arrow-right"></i></a>
								</div>
							</div>
						</li>
						<li class="nav-item notification_dropdown">
							<a class="nav-link btn-chatbox" href="javascript:void(0);" aria-label="Sidabar Chatbox">
								<svg width="20" height="22" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M16.9026 6.85114L12.4593 10.4642C11.6198 11.1302 10.4387 11.1302 9.59922 10.4642L5.11844 6.85114" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
									<path fill-rule="evenodd" clip-rule="evenodd" d="M15.9089 19C18.9502 19.0084 21 16.5095 21 13.4384V6.57001C21 3.49883 18.9502 1 15.9089 1H6.09114C3.04979 1 1 3.49883 1 6.57001V13.4384C1 16.5095 3.04979 19.0084 6.09114 19H15.9089Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</a>
						</li>
						<li class="nav-item d-none d-sm-flex">
							<a class="nav-link dz-fullscreen" href="javascript:void(0);" aria-label="Fullscreen">
								<svg id="icon-full" viewBox="0 0 24 24" width="20" height="20" stroke="white" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
									<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" style="stroke-dasharray: 37, 57; stroke-dashoffset: 0;"></path>
								</svg>
								<svg id="icon-minimize" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize">
									<path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" style="stroke-dasharray: 37, 57; stroke-dashoffset: 0;"></path>
								</svg>
							</a>
						</li>	
						<li class="nav-item dropdown header-profile-dropdown">
							<a class="nav-link" href="javascript:void(0);" role="button" data-bs-toggle="dropdown" aria-expanded="false">
								<div class="profile-head">
									<div class="profile-media">
										<img src="../assets/images/tab/1.jpg" alt="">
									</div>
									<div class="header-info">
										<h6 class="author-name">Thomas Fleming</h6>
										<small>info@gmail.com</small>
									</div>
								</div>
							</a>
							<ul class="dropdown-menu dropdown-menu-end">
								<li>
									<div class="py-2 d-flex px-3">
										<img src="../assets/images/tab/1.jpg" class="avatar avatar-sm rounded-circle" alt="">
										<div class="ms-2">
											<h6 class="mb-0">Thomas Fleming</h6>
											<small>Web Designer</small>
										</div>	
									</div>
								</li>
								<li><hr class="dropdown-divider"></li>
								<li>
									<a class="dropdown-item" href="app-profile.html">
										<svg  width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path fill-rule="evenodd" clip-rule="evenodd" d="M11.9848 15.3462C8.11714 15.3462 4.81429 15.931 4.81429 18.2729C4.81429 20.6148 8.09619 21.2205 11.9848 21.2205C15.8524 21.2205 19.1543 20.6348 19.1543 18.2938C19.1543 15.9529 15.8733 15.3462 11.9848 15.3462Z" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											<path fill-rule="evenodd" clip-rule="evenodd" d="M11.9848 12.0059C14.5229 12.0059 16.58 9.94779 16.58 7.40969C16.58 4.8716 14.5229 2.81445 11.9848 2.81445C9.44667 2.81445 7.38857 4.8716 7.38857 7.40969C7.38 9.93922 9.42381 11.9973 11.9524 12.0059H11.9848Z" stroke="var(--bs-primary)" stroke-width="1.42857" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
										<span class="ms-2">Profile</span>
									</a>
								</li>
								<li>
									<a class="dropdown-item" href="app-profile.html">
										<svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-pie-chart">
											<path stroke="var(--bs-primary)" d="M21.21 15.89A10 10 0 1 1 8 2.83"></path>
											<path stroke="var(--bs-primary)" d="M22 12A10 10 0 0 0 12 2v10z"></path>
										</svg>
										<span class="ms-2">My Project</span>
										<span class="badge badge-sm badge-primary light rounded-circle float-end">4</span>
									</a>
								</li>
								<li>
									<a href="javascript:void(0);" class="dropdown-item">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M17.9026 8.85114L13.4593 12.4642C12.6198 13.1302 11.4387 13.1302 10.5992 12.4642L6.11844 8.85114" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											<path fill-rule="evenodd" clip-rule="evenodd" d="M16.9089 21C19.9502 21.0084 22 18.5095 22 15.4384V8.57001C22 5.49883 19.9502 3 16.9089 3H7.09114C4.04979 3 2 5.49883 2 8.57001V15.4384C2 18.5095 4.04979 21.0084 7.09114 21H16.9089Z" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
										<span class="ms-2">Message </span>
									</a>
								</li>
								<li>
									<a href="email-inbox.html" class="dropdown-item">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path fill-rule="evenodd" clip-rule="evenodd" d="M12 17.8476C17.6392 17.8476 20.2481 17.1242 20.5 14.2205C20.5 11.3188 18.6812 11.5054 18.6812 7.94511C18.6812 5.16414 16.0452 2 12 2C7.95477 2 5.31885 5.16414 5.31885 7.94511C5.31885 11.5054 3.5 11.3188 3.5 14.2205C3.75295 17.1352 6.36177 17.8476 12 17.8476Z" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											<path d="M14.3888 20.8572C13.0247 22.372 10.8967 22.3899 9.51947 20.8572" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
										<span class="ms-2">Notification </span>
									</a>
								</li>
								<li>
									<a href="javascript:void(0);" class="dropdown-item">
										<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path fill-rule="evenodd" clip-rule="evenodd" d="M20.8066 7.62355L20.1842 6.54346C19.6576 5.62954 18.4907 5.31426 17.5755 5.83866V5.83866C17.1399 6.09528 16.6201 6.16809 16.1307 6.04103C15.6413 5.91396 15.2226 5.59746 14.9668 5.16131C14.8023 4.88409 14.7139 4.56833 14.7105 4.24598V4.24598C14.7254 3.72916 14.5304 3.22834 14.17 2.85761C13.8096 2.48688 13.3145 2.2778 12.7975 2.27802H11.5435C11.0369 2.27801 10.5513 2.47985 10.194 2.83888C9.83666 3.19791 9.63714 3.68453 9.63958 4.19106V4.19106C9.62457 5.23686 8.77245 6.07675 7.72654 6.07664C7.40418 6.07329 7.08843 5.98488 6.8112 5.82035V5.82035C5.89603 5.29595 4.72908 5.61123 4.20251 6.52516L3.53432 7.62355C3.00838 8.53633 3.31937 9.70255 4.22997 10.2322V10.2322C4.82187 10.574 5.1865 11.2055 5.1865 11.889C5.1865 12.5725 4.82187 13.204 4.22997 13.5457V13.5457C3.32053 14.0719 3.0092 15.2353 3.53432 16.1453V16.1453L4.16589 17.2345C4.41262 17.6797 4.82657 18.0082 5.31616 18.1474C5.80575 18.2865 6.33061 18.2248 6.77459 17.976V17.976C7.21105 17.7213 7.73116 17.6515 8.21931 17.7821C8.70746 17.9128 9.12321 18.233 9.37413 18.6716C9.53867 18.9488 9.62708 19.2646 9.63043 19.5869V19.5869C9.63043 20.6435 10.4869 21.5 11.5435 21.5H12.7975C13.8505 21.5 14.7055 20.6491 14.7105 19.5961V19.5961C14.7081 19.088 14.9088 18.6 15.2681 18.2407C15.6274 17.8814 16.1154 17.6806 16.6236 17.6831C16.9451 17.6917 17.2596 17.7797 17.5389 17.9393V17.9393C18.4517 18.4653 19.6179 18.1543 20.1476 17.2437V17.2437L20.8066 16.1453C21.0617 15.7074 21.1317 15.1859 21.0012 14.6963C20.8706 14.2067 20.5502 13.7893 20.111 13.5366V13.5366C19.6717 13.2839 19.3514 12.8665 19.2208 12.3769C19.0902 11.8872 19.1602 11.3658 19.4153 10.9279C19.5812 10.6383 19.8213 10.3981 20.111 10.2322V10.2322C21.0161 9.70283 21.3264 8.54343 20.8066 7.63271V7.63271V7.62355Z" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
											<circle cx="12.175" cy="11.889" r="2.63616" stroke="var(--bs-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
										<span class="ms-2">Settings </span>
									</a>
								</li>
								<li><hr class="dropdown-divider"></li>
								<li>
									<a href="page-login.html" class="dropdown-item">
										<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--bs-danger)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
											<path stroke="var(--bs-danger)" d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
											<polyline stroke="var(--bs-danger)" points="16 17 21 12 16 7"></polyline>
											<line x1="21" y1="12" x2="9" y2="12"></line>
										</svg>
										<span class="ms-2 text-danger">Logout </span>
									</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
		</div>
	</div>
	<!-- End - Header -->
		
			<!-- Start - Sidebar Navigation -->
	<div class="deznav">
		<div class="deznav-scroll">
			<ul class="metismenu" id="menu">
				<li class="menu-title">YOUR COMPANY</li>
				<li>
					<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M2.5 7.49999L10 1.66666L17.5 7.49999V16.6667C17.5 17.1087 17.3244 17.5326 17.0118 17.8452C16.6993 18.1577 16.2754 18.3333 15.8333 18.3333H4.16667C3.72464 18.3333 3.30072 18.1577 2.98816 17.8452C2.67559 17.5326 2.5 17.1087 2.5 16.6667V7.49999Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M7.5 18.3333V10H12.5V18.3333" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Dashboard</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="index.html">Dashboard Light</a></li>
						<li><a href="index-2.html">Dashboard Dark</a></li>
					</ul>
				</li>
				<li>
					<a href="employee.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 14.0673C7.4407 14.0673 4.41309 14.6034 4.41309 16.7501C4.41309 18.8969 7.4215 19.4521 10.986 19.4521C14.5313 19.4521 17.5581 18.9152 17.5581 16.7693C17.5581 14.6234 14.5505 14.0673 10.986 14.0673Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 11.0054C13.3126 11.0054 15.1983 9.11881 15.1983 6.79223C15.1983 4.46564 13.3126 2.57993 10.986 2.57993C8.65944 2.57993 6.77285 4.46564 6.77285 6.79223C6.76499 9.11096 8.63849 10.9975 10.9563 11.0054H10.986Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Employees</span>
					</a>
				</li>
				<li>
					<a href="core-hr.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M15.8381 12.7317C16.4566 12.7317 16.9757 13.2422 16.8811 13.853C16.3263 17.4463 13.2502 20.1143 9.54009 20.1143C5.43536 20.1143 2.10834 16.7873 2.10834 12.6835C2.10834 9.30245 4.67693 6.15297 7.56878 5.44087C8.19018 5.28745 8.82702 5.72455 8.82702 6.36429C8.82702 10.6987 8.97272 11.8199 9.79579 12.4297C10.6189 13.0396 11.5867 12.7317 15.8381 12.7317Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M19.8848 9.1223C19.934 6.33756 16.5134 1.84879 12.345 1.92599C12.0208 1.93178 11.7612 2.20195 11.7468 2.5252C11.6416 4.81493 11.7834 7.78204 11.8626 9.12713C11.8867 9.5459 12.2157 9.87493 12.6335 9.89906C14.0162 9.97818 17.0914 10.0862 19.3483 9.74467C19.6552 9.69835 19.88 9.43204 19.8848 9.1223Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>
						<span class="nav-text">Core HR</span>
					</a>
				</li>
				<li>
					<a href="finance.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M6.64111 13.5497L9.38482 9.9837L12.5145 12.4421L15.1995 8.97684" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<ellipse cx="18.3291" cy="3.85021" rx="1.76201" ry="1.76201" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13.6808 2.86012H7.01867C4.25818 2.86012 2.54651 4.81512 2.54651 7.57561V14.9845C2.54651 17.7449 4.22462 19.6915 7.01867 19.6915H14.9058C17.6663 19.6915 19.3779 17.7449 19.3779 14.9845V8.53213" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Finance</span>
					</a>
				</li>
				<li>
					<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M10.5346 2.55658H7.1072C4.28845 2.55658 2.52112 4.55216 2.52112 7.37733V14.9985C2.52112 17.8237 4.2802 19.8192 7.1072 19.8192H15.1959C18.0238 19.8192 19.7829 17.8237 19.7829 14.9985V11.3062" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M8.09214 10.0108L14.9424 3.16057C15.7958 2.30807 17.1791 2.30807 18.0325 3.16057L19.1481 4.27615C20.0015 5.12957 20.0015 6.51374 19.1481 7.36624L12.2648 14.2495C11.8917 14.6226 11.3857 14.8325 10.8577 14.8325H7.42389L7.51006 11.3675C7.52289 10.8578 7.73097 10.372 8.09214 10.0108Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13.9014 4.21895L18.0869 8.40445" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Tasks</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="task.html">Tasks</a></li>
						<li><a href="task-summary.html">Task Summary</a></li>
					</ul>
				</li>
				<li>
					<a href="performance.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M14.9732 2.52102H7.0266C4.25735 2.52102 2.52118 4.48177 2.52118 7.25651V14.7438C2.52118 17.5186 4.2491 19.4793 7.0266 19.4793H14.9723C17.7507 19.4793 19.4795 17.5186 19.4795 14.7438V7.25651C19.4795 4.48177 17.7507 2.52102 14.9732 2.52102Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M7.73657 11.0002L9.91274 13.1754L14.2632 8.82493" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Performance</span>
					</a>
				</li>
				<li>
					<a href="project.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M6.75713 9.35157V15.64" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M11.0349 6.34253V15.64" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M15.2428 12.6746V15.64" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M15.2952 1.83333H6.70474C3.7103 1.83333 1.83331 3.95274 1.83331 6.95306V15.0469C1.83331 18.0473 3.70157 20.1667 6.70474 20.1667H15.2952C18.2984 20.1667 20.1666 18.0473 20.1666 15.0469V6.95306C20.1666 3.95274 18.2984 1.83333 15.2952 1.83333Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Projects</span>
					</a>
				</li>
				<li>
					<a href="reports.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M13.5096 2.53165H7.41104C5.50437 2.52432 3.94146 4.04415 3.89654 5.9499V15.7701C3.85437 17.7071 5.38979 19.3121 7.32671 19.3552C7.35512 19.3552 7.38262 19.3561 7.41104 19.3552H14.7343C16.6538 19.2773 18.1663 17.6915 18.1525 15.7701V7.36798L13.5096 2.53165Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13.2688 2.52084V5.18742C13.2688 6.48909 14.3211 7.54417 15.6228 7.54784H18.1482" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13.0974 14.0786H8.1474" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M11.2229 10.6388H8.14655" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Reports</span>
					</a>
				</li>
				<li>
					<a href="manage-client.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M8.79222 13.9396C12.1738 13.9396 15.0641 14.452 15.0641 16.4989C15.0641 18.5458 12.1931 19.0729 8.79222 19.0729C5.40972 19.0729 2.52039 18.5651 2.52039 16.5172C2.52039 14.4694 5.39047 13.9396 8.79222 13.9396Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M8.79223 11.0182C6.57206 11.0182 4.77173 9.21874 4.77173 6.99857C4.77173 4.7784 6.57206 2.97898 8.79223 2.97898C11.0115 2.97898 12.8118 4.7784 12.8118 6.99857C12.8201 9.21049 11.0326 11.0099 8.82064 11.0182H8.79223Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M15.1095 9.9748C16.5771 9.76855 17.7073 8.50905 17.7101 6.98464C17.7101 5.48222 16.6147 4.23555 15.1782 3.99997" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M17.0458 13.5045C18.4675 13.7163 19.4603 14.2149 19.4603 15.2416C19.4603 15.9483 18.9928 16.4067 18.2374 16.6936" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Manage Clients</span>
					</a>
				</li>
				<li>
					<a href="blog.html" aria-expanded="false">
						<div class="menu-icon">
							<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M16.334 2.75012H7.665C4.644 2.75012 2.75 4.88912 2.75 7.91612V16.0841C2.75 19.1111 4.635 21.2501 7.665 21.2501H16.333C19.364 21.2501 21.25 19.1111 21.25 16.0841V7.91612C21.25 4.88912 19.364 2.75012 16.334 2.75012Z" stroke="#888888" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M11.9946 16.0001V12.0001" stroke="#888888" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M11.9896 8.20435H11.9996" stroke="#888888" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>
						<span class="nav-text">Blog</span>
					</a>
				</li>
				<li class="menu-title">OUR FEATURES</li>
				<li>
					<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 14.0673C7.4407 14.0673 4.41309 14.6034 4.41309 16.7501C4.41309 18.8969 7.4215 19.4521 10.986 19.4521C14.5313 19.4521 17.5581 18.9152 17.5581 16.7693C17.5581 14.6234 14.5505 14.0673 10.986 14.0673Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 11.0054C13.3126 11.0054 15.1983 9.11881 15.1983 6.79223C15.1983 4.46564 13.3126 2.57993 10.986 2.57993C8.65944 2.57993 6.77285 4.46564 6.77285 6.79223C6.76499 9.11096 8.63849 10.9975 10.9563 11.0054H10.986Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Profile </span>
					</a>
					<ul aria-expanded="false">
						<li><a href="profile/overview.html">Overview</a></li>
						<li><a href="profile/projects.html">Projects</a></li>
						<li><a href="profile/projects-details.html">Projects Details</a></li>
						<li><a href="profile/campaigns.html">Campaigns</a></li>
						<li><a href="profile/documents.html">Documents</a></li>
						<li><a href="profile/followers.html">Followers</a></li>
						<li><a href="profile/activity.html">Activity</a></li>
					</ul>
				</li>
				<li>
					<a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 14.0673C7.4407 14.0673 4.41309 14.6034 4.41309 16.7501C4.41309 18.8969 7.4215 19.4521 10.986 19.4521C14.5313 19.4521 17.5581 18.9152 17.5581 16.7693C17.5581 14.6234 14.5505 14.0673 10.986 14.0673Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M10.986 11.0054C13.3126 11.0054 15.1983 9.11881 15.1983 6.79223C15.1983 4.46564 13.3126 2.57993 10.986 2.57993C8.65944 2.57993 6.77285 4.46564 6.77285 6.79223C6.76499 9.11096 8.63849 10.9975 10.9563 11.0054H10.986Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">Account</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="account/overview.html">Overview</a></li>
						<li><a href="account/settings.html">Settings</a></li>
						<li><a href="account/security.html">Security</a></li>
						<li><a href="account/activity.html">Activity</a></li>
						<li><a href="account/billing.html">Billing</a></li>
						<li><a href="account/statements.html">Statements</a></li>
						<li><a href="account/referrals.html">Referrals</a></li>
						<li><a href="account/api-keys.html">Api Keys</a></li>
						<li><a href="account/logs.html">Logs</a></li>
					</ul>
				</li>
				<li>
					<a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M7.11086 10.2878V13.7208" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M8.86244 12.0045H5.35974" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M13.0856 10.3924H12.9875" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M14.748 13.6691H14.6499" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path d="M6.39948 0.833328C6.39948 1.5121 6.96092 2.06236 7.65349 2.06236H8.62193C9.69042 2.06617 10.5559 2.9144 10.5608 3.9616V4.5804" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M14.0593 19.1324C11.3045 19.1791 8.60026 19.1771 5.94166 19.1324C2.99069 19.1324 0.833313 17.0275 0.833313 14.1354V9.87325C0.833313 6.98107 2.99069 4.8762 5.94166 4.8762C8.61483 4.83051 11.321 4.83146 14.0593 4.8762C17.0102 4.8762 19.1666 6.98203 19.1666 9.87325V14.1354C19.1666 17.0275 17.0102 19.1324 14.0593 19.1324Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>
						<span class="nav-text">Apps</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="chat.html">Chat</a></li>
						<li>
							<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Users Manager</a>
							<ul aria-expanded="false">
								<li><a href="user.html">User</a></li>
								<li><a href="user-roles.html">Roles Listing </a></li>
								<li><a href="add-role.html">Add Roles</a></li>
								<li><a href="app-profile.html">Profile 1</a></li>
								<li><a href="app-profile-2.html">Profile 2</a></li>
								<li><a href="edit-profile.html">Edit Profile</a></li>
								<li><a href="post-details.html">Post Details</a></li>
							</ul>
						</li>
						<li>
							<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Customer Manager</a>
							<ul aria-expanded="false">
								<li><a href="customer.html">Customer</a></li>
								<li><a href="customer-profile.html">Customer Profile</a></li>
							</ul>
						</li>
						<li><a href="contacts.html">Contacts</a></li>
						<li>
							<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Email</a>
							<ul aria-expanded="false">
								<li><a href="email-compose.html">Compose</a></li>
								<li><a href="email-inbox.html">Inbox</a></li>
								<li><a href="email-read.html">Read</a></li>
							</ul>
						</li>
						<li><a href="app-calender.html">Calendar</a></li>
						<li>
							<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Shop</a>
							<ul aria-expanded="false">
								<li><a href="ecom-product-grid.html">Product Grid</a></li>
								<li><a href="ecom-product-list.html">Product List</a></li>
								<li><a href="ecom-product-detail.html">Product Details</a></li>
								<li><a href="ecom-product-order.html">Order</a></li>
								<li><a href="ecom-checkout.html">Checkout</a></li>
								<li><a href="ecom-invoice.html">Invoice</a></li>
								<li><a href="ecom-customers.html">Customers</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li>
					<a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
								<g clip-path="url(#clip0_14_1294)">
								<path d="M12.1498 18.1013H8.30563L7.86828 15.8455H5.15205L4.71469 18.1013H1.05469L3.67883 3.80664H9.52563L12.1498 18.1013ZM7.43092 13.1523L6.62526 8.04211H6.46413L5.65847 13.1523H7.43092Z" stroke="#888888"/>
								<path d="M17.4903 3.80664H13.5771V18.1013H17.4903V3.80664Z" stroke="#888888"/>
								<mask id="mask0_14_1294" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="6" y="0" width="21" height="20">
								<path d="M16.6266 0.00350988L6.97803 9.84375L16.8183 19.4923L26.4668 9.65207L16.6266 0.00350988Z" stroke="#888888"/>
								</mask>
								<g mask="url(#mask0_14_1294)">
								<path d="M14.7219 3.91233L14.8299 14.8991L18.7149 14.8609L18.609 4.09213L16.632 0.00825376L14.7219 3.91233ZM18.281 14.4355L15.2553 14.4652L15.1592 4.68853L15.3838 4.90622L15.8065 4.47173L16.2438 4.89717L16.6711 4.46324L17.1063 4.89177L17.5245 4.45487L17.9687 4.88023L18.1848 4.65719L18.281 14.4355ZM18.1324 4.09379L17.9573 4.27443L17.5112 3.84721L17.0972 4.27979L16.6664 3.85554L16.2373 4.29131L15.7981 3.86408L15.3748 4.29917L15.1532 4.08445L15.1525 4.00974L16.0974 2.07838L16.6448 2.43559L17.1599 2.08482L18.1324 4.09379ZM16.6397 1.91931L16.2877 1.68959L16.6299 0.990098L16.9707 1.69393L16.6397 1.91931Z" stroke="#888888"/>
								<path d="M14.8359 15.545L18.7114 15.5068L18.7072 15.0772L14.8316 15.1153L14.8359 15.545Z" stroke="#888888"/>
								<path d="M14.8521 17.1728C14.8573 17.7 15.2905 18.1248 15.8178 18.1196L17.7798 18.1003C18.0352 18.0978 18.2744 17.996 18.4532 17.8136C18.632 17.6312 18.7291 17.3901 18.7266 17.1347L18.7127 15.7235L14.8383 15.7616L14.8521 17.1728ZM18.297 17.1389C18.2984 17.2796 18.2449 17.4123 18.1465 17.5128C18.048 17.6132 17.9163 17.6693 17.7756 17.6707L15.8136 17.69C15.5232 17.6929 15.2846 17.4589 15.2818 17.1686L15.2721 16.1871L18.2874 16.1574L18.297 17.1389Z" stroke="#888888"/>
								</g>
								</g>
								<defs>
								<clipPath id="clip0_14_1294">
								<rect width="20" height="20" stroke="#888888"/>
								</clipPath>
								</defs>
							</svg>
						</div>
						<span class="nav-text">AIKit</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="aikit/auto-write.html">Auto Writer</a></li>
						<li><a href="aikit/scheduled.html">Scheduler</a></li>
						<li><a href="aikit/repurpose.html">Repurpose</a></li>
						<li><a href="aikit/rss.html">RSS</a></li>
						<li><a href="aikit/chatbot.html">Chatbot</a></li>
						<li><a href="aikit/fine-tune-models.html">Fine-tune Models</a></li>
						<li><a href="aikit/prompt.html">AI Menu Prompts</a></li>
						<li><a href="aikit/setting.html">Settings</a></li>
						<li><a href="aikit/import.html">Export/Import Settings</a></li>
					</ul>
				</li>
				<li>
					<a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M20.8064 7.62355L20.184 6.54346C19.6574 5.62954 18.4905 5.31426 17.5753 5.83866V5.83866C17.1397 6.09528 16.6198 6.16809 16.1305 6.04103C15.6411 5.91396 15.2224 5.59746 14.9666 5.16131C14.8021 4.88409 14.7137 4.56833 14.7103 4.24598V4.24598C14.7251 3.72916 14.5302 3.22834 14.1698 2.85761C13.8094 2.48688 13.3143 2.2778 12.7973 2.27802H11.5433C11.0367 2.27801 10.5511 2.47985 10.1938 2.83888C9.83644 3.19791 9.63693 3.68453 9.63937 4.19106V4.19106C9.62435 5.23686 8.77224 6.07675 7.72632 6.07664C7.40397 6.07329 7.08821 5.98488 6.81099 5.82035V5.82035C5.89582 5.29595 4.72887 5.61123 4.20229 6.52516L3.5341 7.62355C3.00817 8.53633 3.31916 9.70255 4.22975 10.2322V10.2322C4.82166 10.574 5.18629 11.2055 5.18629 11.889C5.18629 12.5725 4.82166 13.204 4.22975 13.5457V13.5457C3.32031 14.0719 3.00898 15.2353 3.5341 16.1453V16.1453L4.16568 17.2345C4.4124 17.6797 4.82636 18.0082 5.31595 18.1474C5.80554 18.2865 6.3304 18.2248 6.77438 17.976V17.976C7.21084 17.7213 7.73094 17.6515 8.2191 17.7821C8.70725 17.9128 9.12299 18.233 9.37392 18.6716C9.53845 18.9488 9.62686 19.2646 9.63021 19.5869V19.5869C9.63021 20.6435 10.4867 21.5 11.5433 21.5H12.7973C13.8502 21.5 14.7053 20.6491 14.7103 19.5961V19.5961C14.7079 19.088 14.9086 18.6 15.2679 18.2407C15.6272 17.8814 16.1152 17.6806 16.6233 17.6831C16.9449 17.6917 17.2594 17.7797 17.5387 17.9393V17.9393C18.4515 18.4653 19.6177 18.1543 20.1474 17.2437V17.2437L20.8064 16.1453C21.0615 15.7074 21.1315 15.1859 21.001 14.6963C20.8704 14.2067 20.55 13.7893 20.1108 13.5366V13.5366C19.6715 13.2839 19.3511 12.8665 19.2206 12.3769C19.09 11.8872 19.16 11.3658 19.4151 10.9279C19.581 10.6383 19.8211 10.3981 20.1108 10.2322V10.2322C21.0159 9.70283 21.3262 8.54343 20.8064 7.63271V7.63271V7.62355Z" stroke="#888888" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
							<circle cx="12.1747" cy="11.889" r="2.63616" stroke="#888888" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>	
						<span class="nav-text">CMS</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="cms/content.html">Content</a></li>
						<li><a href="cms/content-add.html">Add Content</a></li>
						<li><a href="cms/menu.html">Menus</a></li>	
						<li><a href="cms/email-template.html">Email Template</a></li>		
						<li><a href="cms/add-email.html">Add Email</a></li>		
						<li><a href="cms/blog.html">Blog</a></li>	
						<li><a href="cms/blog-category.html">Blog Category</a></li>	
						<li><a href="cms/add-blog.html">Add Blog</a></li>	
					</ul>
				</li>
				<li>
					<a class="has-arrow" href="javascript:void(0);" aria-expanded="false">
						<div class="menu-icon">
							<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path fill-rule="evenodd" clip-rule="evenodd" d="M16.3691 18.7157C18.086 18.7157 19.4784 17.3242 19.4793 15.6073V15.6055V13.1305C18.3454 13.1305 17.4269 12.212 17.426 11.078C17.426 9.94504 18.3445 9.02562 19.4784 9.02562H19.4793V6.55062C19.4812 4.83279 18.0906 3.43946 16.3737 3.43762H16.3682H5.63216C3.91433 3.43762 2.52191 4.82912 2.521 6.54696V6.54787V9.10537C3.6155 9.06687 4.53308 9.92304 4.57158 11.0175C4.5725 11.0377 4.57341 11.0579 4.57341 11.078C4.57433 12.2101 3.65858 13.1286 2.5265 13.1305H2.521V15.6055C2.52008 17.3224 3.9125 18.7157 5.62941 18.7157H5.63033H16.3691Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
								<path fill-rule="evenodd" clip-rule="evenodd" d="M11.3403 8.30788L11.905 9.45096C11.96 9.5628 12.0663 9.64071 12.1901 9.65905L13.4523 9.8433C13.7649 9.88913 13.8887 10.2723 13.6632 10.4914L12.7502 11.3805C12.6603 11.4676 12.62 11.5932 12.6402 11.717L12.8556 12.9728C12.9087 13.2835 12.5833 13.52 12.3047 13.3734L11.1762 12.7803C11.0653 12.7216 10.9333 12.7216 10.8224 12.7803L9.69491 13.3734C9.41533 13.52 9.08991 13.2835 9.14308 12.9728L9.3585 11.717C9.37958 11.5932 9.33833 11.4676 9.2485 11.3805L8.33641 10.4914C8.11091 10.2723 8.23466 9.88913 8.54633 9.8433L9.80858 9.65905C9.93233 9.64071 10.0396 9.5628 10.0946 9.45096L10.6583 8.30788C10.7977 8.02555 11.201 8.02555 11.3403 8.30788Z" stroke="#888888" stroke-linecap="round" stroke-linejoin="round"/>
							</svg>
						</div>
						<span class="nav-text">Pages</span>
					</a>
					<ul aria-expanded="false">
						<li><a href="page-login.html">Login</a></li>
						<li><a href="page-register.html">Register</a></li>
						<li><a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Error</a>
							<ul aria-expanded="false">
								<li><a href="page-error-400.html">Error 400</a></li>
								<li><a href="page-error-403.html">Error 403</a></li>
								<li><a href="page-error-404.html">Error 404</a></li>
								<li><a href="page-error-500.html">Error 500</a></li>
								<li><a href="page-error-503.html">Error 503</a></li>
							</ul>
						</li>
						<li><a href="page-lock-screen.html">Lock Screen</a></li>
						<li><a href="empty-page.html">Empty Page</a></li>
					</ul>
				</li>
			</ul>
		</div>
		<div class="deznav-footer">
			<a href="https://w3crm.dexignzone.com/doc/" target="_blank" class="btn btn-docs btn-success w-100">
				<span>Docs & Components</span>
				<i class="fa-solid fa-arrow-up rotate-x"></i>
			</a>
		</div>
	</div>
	<!-- End - Sidebar Navigation -->
		
		<!-- Start - Content Body -->
        <main class="content-body">
            
			<!-- Start - Page Title & Breadcrumb -->
			<div class="page-title">
					<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li><h1>Applied Practitioner List</h1></li>
			<li class="breadcrumb-item">
				<a href="index.html">
					<svg width="16" height="16" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M2.125 6.375L8.5 1.41667L14.875 6.375V14.1667C14.875 14.5424 14.7257 14.9027 14.4601 15.1684C14.1944 15.4341 13.8341 15.5833 13.4583 15.5833H3.54167C3.16594 15.5833 2.80561 15.4341 2.53993 15.1684C2.27426 14.9027 2.125 14.5424 2.125 14.1667V6.375Z" stroke="var(--bs-body-color)" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M6.375 15.5833V8.5H10.625V15.5833" stroke="var(--bs-body-color)" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
					Home
				</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">Practtitioner List</li>
		</ol>
	</nav>
				<!-- <a class="text-primary fs-13" data-bs-toggle="offcanvas" href="#addTaskmodal" role="button" aria-controls="addTaskmodal">+ Add Task</a> -->
			</div>
			<!-- End - Page Title & Breadcrumb -->
			
			<?php
// Assume $conn is already defined and connected to the database
$status_filter = isset($_GET['status']) ? strtolower($_GET['status']) : 'pending';
$valid_statuses = ['pending', 'approved', 'active', 'inactive'];

// Validate status_filter
if (!in_array($status_filter, $valid_statuses)) {
    $status_filter = 'pending';
}

// Fetch counts for all statuses
$counts = [
    'pending' => 0,
    'approved' => 0,
    'active' => 0,
    'inactive' => 0
];

foreach ($valid_statuses as $status) {
    $count_sql = "SELECT COUNT(*) as count FROM practitioner WHERE registration_status = '" . ucfirst($status) . "'";
    $count_result = $conn->query($count_sql);
    $counts[$status] = $count_result && $count_result->num_rows > 0 ? $count_result->fetch_assoc()['count'] : 0;
}

// Fetch data for the selected status
$sql = "SELECT p.*, rt.registration_type 
        FROM practitioner p
        LEFT JOIN registration_type_master rt ON p.registration_type_id = rt.registration_type_id
        WHERE p.registration_status = '" . ucfirst($status_filter) . "'
        ORDER BY p.practitioner_id DESC";
$result = $conn->query($sql);
?>
<style>
.transition {
    transition: all 0.3s ease;
}
a:hover .transition {
    transform: scale(1.03);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}
</style>
<div class="container-fluid">
    
<div class="row">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body overflow-hidden">
                <div class="row gx-4 gy-3">
                    <div class="d-flex justify-content-between align-items-center mb-6">
                        <h1 class="mt-2 mb-0 fs-3">Applied Practitioner List </h1>
                    </div>

                    <!-- Pending -->
                    <div class="col-xl-3 col-sm-6 col-6">
                        <a href="?status=pending" class="text-decoration-none">
                            <div class="d-flex align-items-center justify-content-start p-3 rounded shadow-sm transition 
                                <?php echo $status_filter == 'pending' ? 'bg-warning bg-opacity-10 border border-warning' : 'bg-white'; ?>">
                                <h2 class="text-warning my-0 fs-3 me-3"><?php echo $counts['pending']; ?></h2>
                                <span class="text-dark fw-semibold fs-5">Pending</span>
                            </div>
                        </a>
                    </div>

                    <!-- Approved -->
                    <div class="col-xl-3 col-sm-6 col-6">
                        <a href="?status=approved" class="text-decoration-none">
                            <div class="d-flex align-items-center justify-content-start p-3 rounded shadow-sm transition 
                                <?php echo $status_filter == 'approved' ? 'bg-success bg-opacity-10 border border-success' : 'bg-white'; ?>">
                                <h2 class="text-success my-0 fs-3 me-3"><?php echo $counts['approved']; ?></h2>
                                <span class="text-dark fw-semibold fs-5">Approved</span>
                            </div>
                        </a>
                    </div>

                    <!-- Active -->
                    <div class="col-xl-3 col-sm-6 col-6">
                        <a href="?status=active" class="text-decoration-none">
                            <div class="d-flex align-items-center justify-content-start p-3 rounded shadow-sm transition 
                                <?php echo $status_filter == 'active' ? 'bg-primary bg-opacity-10 border border-primary' : 'bg-white'; ?>">
                                <h2 class="text-primary my-0 fs-3 me-3"><?php echo $counts['active']; ?></h2>
                                <span class="text-dark fw-semibold fs-5">Active</span>
                            </div>
                        </a>
                    </div>

                    <!-- Inactive -->
                    <div class="col-xl-3 col-sm-6 col-6">
                        <a href="?status=inactive" class="text-decoration-none">
                            <div class="d-flex align-items-center justify-content-start p-3 rounded shadow-sm transition 
                                <?php echo $status_filter == 'inactive' ? 'bg-danger bg-opacity-10 border border-danger' : 'bg-white'; ?>">
                                <h2 class="text-danger my-0 fs-3 me-3"><?php echo $counts['inactive']; ?></h2>
                                <span class="text-dark fw-semibold fs-5">Inactive</span>
                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header border-0">
                    <h4 class="card-title"><?php echo ucfirst($status_filter); ?> Practitioners</h4>
                    <div class="d-flex">
                        <form method="post" id="bulkActionForm" class="me-2">
                            <input type="hidden" name="bulk_action" id="bulkAction">
                            <input type="hidden" name="selected_practitioners" id="selectedPractitioners">
                            <button type="button" class="btn btn-success me-2" onclick="submitBulkAction('approve')">
                                <i class="fas fa-check-circle"></i> Approve Selected
                            </button>
                            <button type="button" class="btn btn-danger" onclick="submitBulkAction('reject')">
                                <i class="fas fa-times-circle"></i> Reject Selected
                            </button>
                        </form>
                        <div id="tableEmpoloyeesTBL1ExcelBTN"></div>
                    </div>
                </div>
                <div class="card-body table-card-body px-0 pt-0 pb-1">
                    <div class="table-responsive check-wrapper">
                        <table id="taskTable" class="table">
                            <thead class="table-light text-nowrap">
                                <tr>
                                    <th class="mw-50 sorting-disabled">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="checkAll">
                                        </div>
                                    </th>
                                    <th class="mw-50">SI NO</th>
                                    <th class="mw-200">Name</th>
                                    <th class="mw-100">Registration Type</th>
                                    <th class="mw-100">Contact Rubber Stamp</th>
                                    <th class="mw-100">Registration Date</th>
                                    <th class="mw-120">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="text-nowrap">
                                <?php if ($result && $result->num_rows > 0): ?>
                                    <?php while ($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input practitioner-checkbox" value="<?php echo $row['practitioner_id']; ?>">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="clearfix">
                                                    <h6 class="mb-1"><?php echo $row['practitioner_id']; ?></h6>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($row['practitioner_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['registration_type']); ?></td>
                                            <td>
                                                <div><i class="fas fa-envelope text-muted mr-1"></i> <?php echo htmlspecialchars($row['practitioner_email_id']); ?></div>
                                                <div><i class="fas fa-phone text-muted mr-1"></i> <?php echo htmlspecialchars($row['practitioner_mobile_number']); ?></div>
                                            </td>
                                            <td><?php echo date('d M Y', strtotime($row['registration_date'])); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="landing_profile.php?id=<?php echo $row['practitioner_id']; ?>" class="btn btn-sm btn-info" title="View Details">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
													
                                                    <?php if ($status_filter == 'pending' || $status_filter == 'approved'): ?>

                                                        <a href="?action=approve&id=<?php echo $row['practitioner_id']; ?>" class="btn btn-sm btn-success" title="Approve" onclick="return confirm('Are you sure you want to approve this practitioner?');">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        <a href="?action=reject&id=<?php echo $row['practitioner_id']; ?>" class="btn btn-sm btn-danger" title="Reject" onclick="return confirm('Are you sure you want to reject this practitioner?');">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <button class="btn btn-sm btn-warning send-remark-btn" title="Send Remark" 
                                                            data-email="<?php echo htmlspecialchars($row['practitioner_email_id']); ?>" 
                                                            data-name="<?php echo htmlspecialchars($row['practitioner_name']); ?>" 
                                                            data-id="<?php echo $row['practitioner_id']; ?>">
                                                        <i class="fas fa-comment"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center">No <?php echo $status_filter; ?> applications found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
		<!-- End - Content Body -->
		
			<!-- Start - Footer -->
	
	<!-- End - Footer -->

	
		<!-- End - Add Task Modal -->
		
	</div>
	<!-- End - Main Wrapper -->







    <!-- Email Model -->
     <!-- Email Modal -->
    <div class="modal fade" id="remarkModal" tabindex="-1" role="dialog" aria-labelledby="remarkModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="remarkModalLabel">
                        <i class="fas fa-envelope me-2"></i> Send Remark to <span id="recipientNameTitle">Practitioner</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="remarkForm">
                        <div class="email-header bg-light p-3 mb-3 rounded">
                            <div class="mb-3">
                                <label for="recipientEmail" class="form-label fw-bold text-muted">
                                    <i class="fas fa-at me-1"></i> To:
                                </label>
                                <input type="email" class="form-control-plaintext" id="recipientEmail" readonly>
                            </div>
                            <div class="mb-0">
                                <label for="recipientName" class="form-label fw-bold text-muted">
                                    <i class="fas fa-user me-1"></i> Recipient:
                                </label>
                                <input type="text" class="form-control-plaintext" id="recipientName" readonly>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="remarkMessage" class="form-label fw-bold">
                                <i class="fas fa-comment-alt me-1"></i> Remark
                            </label>
                            <textarea class="form-control" id="remarkMessage" rows="6" 
                                placeholder="Enter your detailed instructions or comments to the practitioner..."></textarea>
                            <div class="form-text">
                                <i class="fas fa-info-circle me-1"></i> Provide clear instructions about what actions the practitioner needs to take.
                            </div>
                        </div>
                        <input type="hidden" id="practitionerId" value="">
                    </form>
                    <div id="loadingSpinner" class="text-center my-4 d-none">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Sending...</span>
                        </div>
                        <p class="mt-2">Sending email, please wait...</p>
                    </div>
                    <div id="successAnimation" class="text-center my-4 d-none">
                        <div class="mb-3">
                            <i class="fas fa-check-circle text-success" style="font-size: 60px;"></i>
                        </div>
                        <h4 class="text-success">Email Sent Successfully!</h4>
                        <p class="text-muted">Your remark has been delivered to the practitioner.</p>
                    </div>
                    <div id="errorMessage" class="alert alert-danger d-none">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <span id="errorText"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Close
                    </button>
                    <button type="button" class="btn btn-primary" id="sendRemarkBtn">
                        <i class="fas fa-paper-plane me-1"></i> Send Remark
                    </button>
                </div>
            </div>
        </div>
    </div>

	
	<!-- Start - Page Scripts -->
    <!-- Required Vendors -->
    <script src="../assets/vendor/global/global.min.js"></script>
    
    <!-- Add SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
    // Show notification function using SweetAlert2
    function showNotification(title, message, type) {
        Swal.fire({
            title: title,
            text: message,
            icon: type,
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
        });
    }

    // Show confirmation dialog using SweetAlert2
    function showConfirmation(title, message, callback) {
        Swal.fire({
            title: title,
            text: message,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, proceed!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                callback();
            }
        });
    }

    // Checkbox functionality
    document.getElementById('checkAll').addEventListener('change', function() {
        const checkboxes = document.getElementsByClassName('practitioner-checkbox');
        for (let checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });

    // Bulk action functionality
    function submitBulkAction(action) {
        const checkboxes = document.getElementsByClassName('practitioner-checkbox');
        const selectedIds = [];
        
        for (let checkbox of checkboxes) {
            if (checkbox.checked) {
                selectedIds.push(checkbox.value);
            }
        }

        if (selectedIds.length === 0) {
            showNotification(
                'No Selection',
                'Please select at least one practitioner',
                'warning'
            );
            return;
        }

        showConfirmation(
            'Confirm Action',
            `Are you sure you want to ${action} the selected practitioners?`,
            function() {
                document.getElementById('bulkAction').value = action;
                document.getElementById('selectedPractitioners').value = JSON.stringify(selectedIds);
                document.getElementById('bulkActionForm').submit();
            }
        );
    }

    // Send Remark functionality
    document.addEventListener('DOMContentLoaded', function() {
        const remarkModal = new bootstrap.Modal(document.getElementById('remarkModal'));
        
        // Handle send remark button clicks
        document.querySelectorAll('.send-remark-btn').forEach(button => {
            button.addEventListener('click', function() {
                const email = this.dataset.email;
                const name = this.dataset.name;
                const id = this.dataset.id;

                document.getElementById('recipientEmail').value = email;
                document.getElementById('recipientName').value = name;
                document.getElementById('practitionerId').value = id;
                document.getElementById('recipientNameTitle').textContent = name;
                
                // Reset form state
                document.getElementById('remarkMessage').value = '';
                document.getElementById('loadingSpinner').classList.add('d-none');
                document.getElementById('successAnimation').classList.add('d-none');
                document.getElementById('errorMessage').classList.add('d-none');
                document.getElementById('remarkForm').classList.remove('d-none');
                document.getElementById('sendRemarkBtn').disabled = false;

                remarkModal.show();
            });
        });

        // Handle send remark submission
        document.getElementById('sendRemarkBtn').addEventListener('click', function() {
            const email = document.getElementById('recipientEmail').value;
            const name = document.getElementById('recipientName').value;
            const message = document.getElementById('remarkMessage').value;

            if (!message.trim()) {
                showNotification(
                    'Required Field',
                    'Please enter a remark message',
                    'warning'
                );
                return;
            }

            // Show loading state
            Swal.fire({
                title: 'Sending...',
                text: 'Please wait while we send your remark.',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                }
            });

            // Send the remark
            fetch('send_remark.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `email=${encodeURIComponent(email)}&name=${encodeURIComponent(name)}&message=${encodeURIComponent(message)}`
            })
            .then(response => response.text())
            .then(result => {
                if (result.includes('successfully')) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: 'Your remark has been sent successfully.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        remarkModal.hide();
                    });
                } else {
                    throw new Error(result);
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: error.message || 'Failed to send remark. Please try again.'
                });
            });
        });
    });

    // Show SweetAlert notifications for PHP messages
    <?php if (isset($message)): ?>
    document.addEventListener('DOMContentLoaded', function() {
        showNotification(
            '<?php echo $alert_type == "success" ? "Success!" : "Error!"; ?>',
            '<?php echo addslashes($message); ?>',
            '<?php echo $alert_type; ?>'
        );
    });
    <?php endif; ?>

    <?php if (isset($auto_message)): ?>
    document.addEventListener('DOMContentLoaded', function() {
        showNotification(
            'System Update',
            '<?php echo addslashes($auto_message); ?>',
            '<?php echo $auto_alert_type; ?>'
        );
    });
    <?php endif; ?>
    </script>

    <!-- Script For Datatables -->
    <script src="../assets/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../assets/vendor/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../assets/vendor/datatables/js/buttons.html5.min.js"></script>
    <script src="../assets/vendor/datatables/js/jszip.min.js"></script>
    
    <!-- Script For Bootstrap Datepicker -->
    <script src="../assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    
    <!-- Script For Dashboard -->
    <script src="../assets/js/dashboard/dashboard.js"></script>
    
    <!-- Script For Multiple Languages -->
    <script src="../assets/js/jquery.localizationTool.js"></script>
    <script src="../assets/js/translator.js"></script>
    
    <!-- Script For Custom JS -->
    <script src="../assets/js/deznav-init.js"></script>
    <script src="../assets/js/custom.js"></script>
</body>
</html>

