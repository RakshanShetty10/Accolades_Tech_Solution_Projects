(function($) {
    "use strict"

    new dzSettings({
        headerPosition: "fixed",
    });


})(jQuery);