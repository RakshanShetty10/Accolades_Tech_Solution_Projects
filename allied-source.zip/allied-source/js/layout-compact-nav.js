(function($) {
    "use strict"
    
    new dzSettings({
        sidebarStyle: "compact"
    });


})(jQuery);