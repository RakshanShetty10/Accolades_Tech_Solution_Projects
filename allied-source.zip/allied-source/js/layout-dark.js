(function($) {
    "use strict"

    new dzSettings({
        version: "dark"
    });


})(jQuery);