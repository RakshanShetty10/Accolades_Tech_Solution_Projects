<?php
// Site information
$site_full = "Karnataka State Allied Health Council";
$site_short = "KSAHC";
// $site_url = "https://ksahc.karnataka.gov.in/";
$site_url = "http://localhost/Accolades_Tech_Solution_Projects/allied-source/";
$president_name="Dr.U.T. Ifthikar";
$president_qualification=" Chairman, KSAHC";


// Meta tags and common head elements for all pages
?>