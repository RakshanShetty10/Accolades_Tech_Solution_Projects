<?php

    $host = "localhost";
    $username = "root";
    $password = '';
    $database = "ksahc_allied";

    $conn = mysqli_connect($host, $username, $password, $database);

?>